package com.agon.app.network

import com.agon.app.data.BoardSide
import com.agon.app.data.DominoTile
import com.agon.app.data.GameMode
import com.agon.app.data.GameUiState
import com.agon.app.data.Player
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object MessageProtocol {
    const val PORT: Int = 45678
    const val DISCOVERY_PORT: Int = 45679
    const val MULTICAST_GROUP: String = "239.7.7.7"

    val json: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        classDiscriminator = "kind"
    }

    fun encode(message: NetworkMessage): String = json.encodeToString(message)

    fun decode(text: String): NetworkMessage = json.decodeFromString(text)
}

@Serializable
sealed class NetworkMessage {
    abstract val sessionId: String

    @Serializable
    @SerialName("HELLO")
    data class Hello(
        override val sessionId: String,
        val requestedName: String,
    ) : NetworkMessage()

    @Serializable
    @SerialName("WELCOME")
    data class Welcome(
        override val sessionId: String,
        val assignedPlayerId: Int,
        val snapshot: NetworkGameSnapshot,
    ) : NetworkMessage()

    @Serializable
    @SerialName("PLAY_MOVE")
    data class PlayMove(
        override val sessionId: String,
        val playerId: Int,
        val tileId: Int,
        val tile: String,
        val side: String,
    ) : NetworkMessage()

    @Serializable
    @SerialName("DRAW_OR_PASS")
    data class DrawOrPass(
        override val sessionId: String,
        val playerId: Int,
    ) : NetworkMessage()

    @Serializable
    @SerialName("SNAPSHOT")
    data class Snapshot(
        override val sessionId: String,
        val snapshot: NetworkGameSnapshot,
    ) : NetworkMessage()

    @Serializable
    @SerialName("RESYNC_REQUEST")
    data class ResyncRequest(
        override val sessionId: String,
        val playerId: Int,
        val reason: String,
    ) : NetworkMessage()
}

@Serializable
data class RoomAnnouncement(
    val sessionId: String,
    val roomName: String,
    val hostAddress: String,
    val port: Int,
    val connectedPlayers: Int,
    val maxPlayers: Int = 4,
)

@Serializable
data class NetworkRoom(
    val sessionId: String,
    val roomName: String,
    val hostAddress: String,
    val port: Int,
    val connectedPlayers: Int,
    val maxPlayers: Int,
)

@Serializable
data class NetworkGameSnapshot(
    val version: Long,
    val roundNumber: Int,
    val stock: List<NetworkTile>,
    val players: List<NetworkPlayer>,
    val boardTiles: List<NetworkTile>,
    val currentPlayerIndex: Int,
    val leftEnd: Int? = null,
    val rightEnd: Int? = null,
    val roundOver: Boolean,
    val winnerId: Int? = null,
    val scores: Map<Int, Int>,
    val message: String,
    val gameMode: String,
    val connectedPlayerIds: List<Int>,
) {
    fun checksum(): Int {
        val source = buildString {
            append(version).append('|').append(currentPlayerIndex).append('|').append(stock.joinToString { it.id.toString() })
            append('|').append(boardTiles.joinToString { "${it.id}:${it.left}:${it.right}" })
            players.forEach { player -> append('|').append(player.id).append(':').append(player.hand.joinToString { it.id.toString() }) }
        }
        return source.hashCode()
    }
}

@Serializable
data class NetworkTile(
    val id: Int,
    val left: Int,
    val right: Int,
    val isRotated: Boolean = false,
    val isPlayed: Boolean = false,
)

@Serializable
data class NetworkPlayer(
    val id: Int,
    val name: String,
    val hand: List<NetworkTile>,
    val isAi: Boolean = false,
    val lastAction: String = "",
)

fun DominoTile.toNetworkTile(): NetworkTile = NetworkTile(id, left, right, isRotated, isPlayed)

fun NetworkTile.toDominoTile(): DominoTile = DominoTile(id, left, right, isRotated, isPlayed)

fun Player.toNetworkPlayer(): NetworkPlayer = NetworkPlayer(id, name, hand.map { it.toNetworkTile() }, isAi, lastAction)

fun NetworkPlayer.toPlayer(): Player = Player(id, name, hand.map { it.toDominoTile() }, isAi, lastAction)

fun GameUiState.toSnapshot(stockTiles: List<DominoTile>, version: Long, connectedIds: List<Int>): NetworkGameSnapshot = NetworkGameSnapshot(
    version = version,
    roundNumber = roundNumber,
    stock = stockTiles.map { it.toNetworkTile() },
    players = players.map { it.toNetworkPlayer() },
    boardTiles = boardTiles.map { it.toNetworkTile() },
    currentPlayerIndex = currentPlayerIndex,
    leftEnd = leftEnd,
    rightEnd = rightEnd,
    roundOver = roundOver,
    winnerId = winnerId,
    scores = scores,
    message = message,
    gameMode = gameMode.name,
    connectedPlayerIds = connectedIds,
)

fun NetworkGameSnapshot.toUiState(isSyncing: Boolean = false): GameUiState {
    val restoredPlayers = players.map { it.toPlayer() }
    return GameUiState(
        roundNumber = roundNumber,
        players = restoredPlayers,
        currentPlayerIndex = currentPlayerIndex,
        boardTiles = boardTiles.map { it.toDominoTile() },
        leftEnd = leftEnd,
        rightEnd = rightEnd,
        stockCount = stock.size,
        message = message,
        roundOver = roundOver,
        winnerId = winnerId,
        scores = scores,
        handCountsText = restoredPlayers.joinToString("   ") { "${it.displayName()}: ${it.hand.size}" },
        roundInfoText = "الجولة $roundNumber • الدور: ${restoredPlayers.getOrNull(currentPlayerIndex)?.displayName() ?: "لاعب"}",
        boardEndsText = "الطرف الأيسر ${leftEnd ?: "-"}  |  الطرف الأيمن ${rightEnd ?: "-"}",
        currentPlayerHasLegalMove = false,
        gameMode = runCatching { GameMode.valueOf(gameMode) }.getOrDefault(GameMode.FOUR_HUMANS),
        isAiThinking = false,
        networkStatus = if (isSyncing) NetworkStatus.SYNCING else NetworkStatus.CONNECTED,
        networkRole = NetworkRole.CLIENT,
        localPlayerId = null,
        roomName = "غرفة محلية",
        connectedPlayerIds = connectedPlayerIds,
    )
}

enum class NetworkRole { OFFLINE, HOST, CLIENT }

enum class NetworkStatus { OFFLINE, CONNECTED, SYNCING, DISCONNECTED }
