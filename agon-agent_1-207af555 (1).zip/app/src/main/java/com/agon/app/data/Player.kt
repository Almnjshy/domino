package com.agon.app.data

/** لاعب محلي داخل الجهاز، وقد يكون بشرياً أو Bot. */
data class Player(
    val id: Int,
    val name: String,
    val hand: List<DominoTile> = emptyList(),
    val isAi: Boolean = false,
    val lastAction: String = "بانتظار البداية",
) {
    fun handValue(): Int = hand.sumOf { it.sum }

    fun displayName(): String = if (isAi) "$name AI" else name

    fun addTile(tile: DominoTile): Player = copy(hand = hand + tile, lastAction = "سحب ${tile.label()}")

    fun removeTile(tileId: Int): Player = copy(hand = hand.filterNot { it.id == tileId })
}

enum class GameMode(val arabicLabel: String) {
    FOUR_HUMANS("4 لاعبين بشر"),
    HUMAN_VS_AI("لاعب ضد 3 Bots"),
}
