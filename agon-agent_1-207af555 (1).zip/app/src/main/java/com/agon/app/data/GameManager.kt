package com.agon.app.data

import com.agon.app.network.NetworkGameSnapshot
import com.agon.app.network.NetworkRole
import com.agon.app.network.NetworkStatus
import com.agon.app.network.toDominoTile
import com.agon.app.network.toPlayer

/** محرك اللعبة الكامل: توزيع، أدوار، سحب، تمرير، نهاية الجولة ونقاطها. */
class GameManager(
    private val deck: DominoDeck = DominoDeck(),
    private val board: BoardManager = BoardManager(),
    private val ruleEngine: RuleEngine = RuleEngine(),
    private val turnManager: TurnManager = TurnManager(4),
    private val scoreManager: ScoreManager = ScoreManager(),
) {
    private val uiManager = UIManager()
    private var players: List<Player> = emptyList()
    private var roundNumber: Int = 1
    private var consecutivePasses: Int = 0
    private var gameMessage: String = "اضغط لعبة جديدة للبدء"
    private var roundOver: Boolean = false
    private var winnerId: Int? = null
    private var finalScores: Map<Int, Int> = emptyMap()
    private var gameMode: GameMode = GameMode.FOUR_HUMANS

    fun newGame(mode: GameMode = gameMode): GameUiState {
        gameMode = mode
        deck.createShuffledDeck()
        board.clear()
        roundOver = false
        winnerId = null
        finalScores = emptyMap()
        consecutivePasses = 0
        roundNumber = 1

        players = (0 until 4).map { index ->
            val isAi = mode == GameMode.HUMAN_VS_AI && index != 0
            Player(
                id = index,
                name = "لاعب ${index + 1}",
                hand = deck.drawMany(7),
                isAi = isAi,
            )
        }
        val first = determineFirstPlayer(players)
        turnManager.setFirstPlayer(first)
        gameMessage = "يبدأ ${players[first].displayName()} حسب قاعدة أعلى حجر"
        return state()
    }

    fun requestPlay(tile: DominoTile, playerId: Int): GameUiState {
        val side = legalSidesFor(tile).let { sides ->
            when {
                BoardSide.RIGHT in sides -> BoardSide.RIGHT
                BoardSide.LEFT in sides -> BoardSide.LEFT
                else -> null
            }
        } ?: return state("لا توجد حركة قانونية لهذا الحجر")
        return requestPlay(tile, playerId, side)
    }

    fun requestPlay(tile: DominoTile, playerId: Int, side: BoardSide): GameUiState = playTile(playerId, tile.id, side)

    fun playTile(playerId: Int, tileId: Int, side: BoardSide): GameUiState {
        if (roundOver) return state("الجولة منتهية. ابدأ لعبة جديدة.")
        if (!turnManager.isCurrentPlayer(playerId)) return state("ليست حركة ${players.getOrNull(playerId)?.displayName() ?: "هذا اللاعب"}")
        val player = players[playerId]
        val tile = player.hand.firstOrNull { it.id == tileId } ?: return state("الحجر غير موجود في يد اللاعب")
        val legalSides = ruleEngine.legalSides(tile, board)
        if (side !in legalSides) return state("لا يمكن وضع ${tile.label()} على هذا الطرف")

        val placed = if (board.isEmpty) board.placeFirst(tile) else when (side) {
            BoardSide.LEFT -> board.placeLeft(tile)
            BoardSide.RIGHT -> board.placeRight(tile)
        } ?: return state("تعذر وضع الحجر")

        players = players.mapIndexed { index, p ->
            if (index == playerId) p.removeTile(tileId).copy(lastAction = "لعب ${placed.label()}") else p
        }
        consecutivePasses = 0
        gameMessage = "${player.displayName()} لعب ${placed.label()}"

        if (players[playerId].hand.isEmpty()) {
            finishRound("${player.displayName()} أنهى أحجاره")
            return state()
        }

        turnManager.advance()
        return state()
    }

    fun drawUntilPlayableOrPass(playerId: Int): GameUiState {
        if (roundOver) return state("الجولة منتهية")
        if (!turnManager.isCurrentPlayer(playerId)) return state("السحب متاح للاعب الحالي فقط")
        val current = players[playerId]
        if (ruleEngine.hasAnyLegalMove(current, board)) return state("لديك حركة قانونية، اختر حجراً مضاءً")

        var player = current
        var drawnCount = 0
        while (!deck.isEmpty() && !ruleEngine.hasAnyLegalMove(player, board)) {
            val drawn = deck.draw() ?: break
            player = player.addTile(drawn)
            drawnCount++
        }
        players = players.mapIndexed { index, p -> if (index == playerId) player else p }

        return if (ruleEngine.hasAnyLegalMove(player, board)) {
            gameMessage = "${player.displayName()} سحب $drawnCount حجر ووجد حركة قانونية"
            state()
        } else {
            passCurrentPlayer(player, drawnCount)
        }
    }

    fun drawOneForCurrentPlayerOrPass(playerId: Int): GameUiState {
        if (roundOver) return state("الجولة منتهية")
        if (!turnManager.isCurrentPlayer(playerId)) return state("السحب متاح للاعب الحالي فقط")
        val current = players[playerId]
        if (ruleEngine.hasAnyLegalMove(current, board)) return state("${current.displayName()} لديه حركة قانونية")

        val drawn = deck.draw()
        return if (drawn != null) {
            val updated = current.addTile(drawn)
            players = players.mapIndexed { index, p -> if (index == playerId) updated else p }
            gameMessage = "${updated.displayName()} سحب حجراً"
            state()
        } else {
            passCurrentPlayer(current, 0)
        }
    }

    fun legalSidesFor(tile: DominoTile): Set<BoardSide> = ruleEngine.legalSides(tile, board)

    fun currentPlayerHasMove(): Boolean = players.getOrNull(turnManager.currentPlayerIndex)?.let { ruleEngine.hasAnyLegalMove(it, board) } ?: false

    fun stockTiles(): List<DominoTile> = deck.remainingTiles()

    fun restoreFromSnapshot(snapshot: NetworkGameSnapshot): GameUiState {
        players = snapshot.players.map { it.toPlayer() }
        board.restore(snapshot.boardTiles.map { it.toDominoTile() })
        deck.setStock(snapshot.stock.map { it.toDominoTile() })
        roundNumber = snapshot.roundNumber
        finalScores = snapshot.scores
        winnerId = snapshot.winnerId
        roundOver = snapshot.roundOver
        gameMessage = snapshot.message
        gameMode = runCatching { GameMode.valueOf(snapshot.gameMode) }.getOrDefault(GameMode.FOUR_HUMANS)
        turnManager.setFirstPlayer(snapshot.currentPlayerIndex)
        consecutivePasses = 0
        return state()
    }

    fun state(overrideMessage: String? = null): GameUiState {
        val currentPlayer = players.getOrNull(turnManager.currentPlayerIndex) ?: Player(0, "لاعب 1")
        return GameUiState(
            roundNumber = roundNumber,
            players = players,
            currentPlayerIndex = turnManager.currentPlayerIndex,
            boardTiles = board.tiles,
            leftEnd = board.leftEnd,
            rightEnd = board.rightEnd,
            stockCount = deck.remainingCount(),
            message = overrideMessage ?: gameMessage,
            roundOver = roundOver,
            winnerId = winnerId,
            scores = finalScores,
            handCountsText = uiManager.handCounts(players),
            roundInfoText = uiManager.roundInfo(roundNumber, currentPlayer),
            boardEndsText = uiManager.boardEnds(board),
            currentPlayerHasLegalMove = currentPlayerHasMove(),
            gameMode = gameMode,
            isAiThinking = false,
        )
    }

    private fun passCurrentPlayer(player: Player, drawnCount: Int): GameUiState {
        consecutivePasses++
        gameMessage = if (drawnCount > 0) "${player.displayName()} سحب $drawnCount حجر ثم مرر" else "${player.displayName()} مرر الدور"
        if (deck.isEmpty() && consecutivePasses >= players.size) {
            finishRound("انسداد كامل: لا توجد أحجار ولا حركات")
        } else {
            turnManager.advance()
        }
        return state()
    }

    private fun determineFirstPlayer(players: List<Player>): Int {
        val doubles = players.flatMap { player -> player.hand.filter { it.isDouble }.map { player.id to it.left } }
        if (doubles.isNotEmpty()) return doubles.maxBy { it.second }.first
        return players.maxWith(compareBy<Player> { player -> player.hand.maxOf { it.sum } }.thenByDescending { it.id }).id
    }

    private fun finishRound(reason: String) {
        roundOver = true
        finalScores = scoreManager.scores(players)
        val winner = scoreManager.winner(players)
        winnerId = winner?.id
        gameMessage = "$reason. الفائز: ${winner?.displayName() ?: "غير محدد"} بأقل مجموع نقاط"
    }
}

data class GameUiState(
    val roundNumber: Int = 1,
    val players: List<Player> = emptyList(),
    val currentPlayerIndex: Int = 0,
    val boardTiles: List<DominoTile> = emptyList(),
    val leftEnd: Int? = null,
    val rightEnd: Int? = null,
    val stockCount: Int = 0,
    val message: String = "اضغط لعبة جديدة للبدء",
    val roundOver: Boolean = false,
    val winnerId: Int? = null,
    val scores: Map<Int, Int> = emptyMap(),
    val handCountsText: String = "",
    val roundInfoText: String = "الجولة 1",
    val boardEndsText: String = "",
    val currentPlayerHasLegalMove: Boolean = false,
    val gameMode: GameMode = GameMode.FOUR_HUMANS,
    val isAiThinking: Boolean = false,
    val networkStatus: NetworkStatus = NetworkStatus.OFFLINE,
    val networkRole: NetworkRole = NetworkRole.OFFLINE,
    val localPlayerId: Int? = null,
    val roomName: String = "",
    val connectedPlayerIds: List<Int> = emptyList(),
)
