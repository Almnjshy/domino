package com.agon.app.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class AppSettings(
    val volume: Float = 0.75f,
    val effectsEnabled: Boolean = true,
    val language: String = "ar",
    val vibrationEnabled: Boolean = true,
    val preferredMode: GameMode = GameMode.HUMAN_VS_AI,
)

@Serializable
data class PlayerScoreRecord(
    val playerName: String,
    val score: Int,
)

@Serializable
data class MatchHistoryRecord(
    val dateMillis: Long,
    val players: List<String>,
    val winner: String,
    val finalScores: List<PlayerScoreRecord>,
    val durationSeconds: Long,
)

@Serializable
data class StatsData(
    val matchesPlayed: Int = 0,
    val wins: Int = 0,
    val currentWinStreak: Int = 0,
    val longestWinStreak: Int = 0,
    val totalPoints: Int = 0,
    val history: List<MatchHistoryRecord> = emptyList(),
) {
    val winRate: Int get() = if (matchesPlayed == 0) 0 else ((wins * 100f) / matchesPlayed).toInt()
}

class SaveManager(context: Context) {
    private val prefs = context.getSharedPreferences("domino_release_save", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun loadSettings(): AppSettings = runCatching {
        prefs.getString(KEY_SETTINGS, null)?.let { json.decodeFromString<AppSettings>(it) }
    }.getOrNull() ?: AppSettings()

    fun saveSettings(settings: AppSettings) {
        prefs.edit().putString(KEY_SETTINGS, json.encodeToString(settings)).apply()
    }

    fun loadStats(): StatsData = runCatching {
        prefs.getString(KEY_STATS, null)?.let { json.decodeFromString<StatsData>(it) }
    }.getOrNull() ?: StatsData()

    fun saveStats(stats: StatsData) {
        prefs.edit().putString(KEY_STATS, json.encodeToString(stats)).apply()
    }

    companion object {
        private const val KEY_SETTINGS = "settings"
        private const val KEY_STATS = "stats"
    }
}
