package com.agon.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = Color(0xFF3B2E00),
    primaryContainer = Color(0xFF5A4600),
    onPrimaryContainer = Color(0xFFFFE28A),
    secondary = FeltGreen,
    onSecondary = Color.White,
    background = Color(0xFF071910),
    onBackground = Color(0xFFE6F2E9),
    surface = DeepSurface,
    onSurface = Color(0xFFE6F2E9),
    surfaceVariant = Color(0xFF214635),
    onSurfaceVariant = Color(0xFFC2D5C9),
    error = ErrorRed,
)

private val LightColorScheme = lightColorScheme(
    primary = DominoGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB8F2CF),
    onPrimaryContainer = Color(0xFF00210F),
    secondary = GoldAccent,
    onSecondary = Color(0xFF3A3000),
    background = Color(0xFFF8F5E8),
    onBackground = InkBlack,
    surface = WarmSurface,
    onSurface = InkBlack,
    surfaceVariant = Color(0xFFE1EDDF),
    onSurfaceVariant = Color(0xFF3F4D43),
    error = ErrorRed,
)

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content,
    )
}
