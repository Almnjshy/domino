package com.agon.app.data

/** مسؤول بسيط عن صياغة النصوص العربية المشتركة للواجهة. */
class UIManager {
    fun roundInfo(round: Int, currentPlayer: Player): String = "الجولة $round • الدور: ${currentPlayer.displayName()}"

    fun boardEnds(board: BoardManager): String {
        val left = board.leftEnd?.toString() ?: "-"
        val right = board.rightEnd?.toString() ?: "-"
        return "الطرف الأيسر $left  |  الطرف الأيمن $right"
    }

    fun handCounts(players: List<Player>): String = players.joinToString("   ") { "${it.displayName()}: ${it.hand.size}" }
}
