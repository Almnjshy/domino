package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

val DominoGreen = Color(0xFF0F6B3C)
val DominoGreenDark = Color(0xFF083D24)
val FeltGreen = Color(0xFF159457)
val IvoryTile = Color(0xFFFFFDF4)
val InkBlack = Color(0xFF171A18)
val GoldAccent = Color(0xFFE0B84F)
val WarmSurface = Color(0xFFFFF8E8)
val DeepSurface = Color(0xFF10271B)
val ErrorRed = Color(0xFFBA1A1A)
