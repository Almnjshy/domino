package com.agon.app.network

import com.agon.app.data.BoardSide
import com.agon.app.data.DominoTile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class NetworkManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _networkState = MutableStateFlow(NetworkUiState())
    val networkState: StateFlow<NetworkUiState> = _networkState.asStateFlow()
    private val _events = MutableSharedFlow<NetworkEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<NetworkEvent> = _events.asSharedFlow()

    private val clientConnections = ConcurrentHashMap<Int, PeerConnection>()
    private var hostServer: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var discoveryJob: Job? = null
    private var announceJob: Job? = null
    private var sessionId: String = ""
    private var localPlayerId: Int = 0

    fun createRoom(roomName: String = "غرفة الدومينو") {
        stopNetworking()
        sessionId = UUID.randomUUID().toString().take(8).uppercase()
        localPlayerId = 0
        _networkState.value = NetworkUiState(
            role = NetworkRole.HOST,
            status = NetworkStatus.CONNECTED,
            sessionId = sessionId,
            roomName = roomName,
            localPlayerId = 0,
            connectedPlayerIds = listOf(0),
            rooms = emptyList(),
        )
        startHostServer()
        startRoomAnnouncements(roomName)
    }

    fun joinRoom(room: NetworkRoom, playerName: String = "لاعب") {
        stopNetworking(keepRooms = true)
        sessionId = room.sessionId
        _networkState.value = _networkState.value.copy(
            role = NetworkRole.CLIENT,
            status = NetworkStatus.SYNCING,
            sessionId = room.sessionId,
            roomName = room.roomName,
        )
        scope.launch {
            runCatching {
                val socket = Socket()
                socket.connect(InetSocketAddress(room.hostAddress, room.port), 4_000)
                clientSocket = socket
                val connection = PeerConnection(socket)
                connection.send(NetworkMessage.Hello(room.sessionId, playerName))
                listenToHost(connection)
            }.onFailure {
                _networkState.value = _networkState.value.copy(status = NetworkStatus.DISCONNECTED, statusText = "فشل الانضمام: ${it.message}")
            }
        }
    }

    fun startDiscovery() {
        discoveryJob?.cancel()
        discoveryJob = scope.launch {
            val found = LinkedHashMap<String, NetworkRoom>()
            runCatching {
                MulticastSocket(MessageProtocol.DISCOVERY_PORT).use { socket ->
                    socket.reuseAddress = true
                    val group = InetAddress.getByName(MessageProtocol.MULTICAST_GROUP)
                    socket.joinGroup(group)
                    val buffer = ByteArray(2048)
                    while (isActive) {
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        val text = String(packet.data, 0, packet.length)
                        val announcement = MessageProtocol.json.decodeFromString<RoomAnnouncement>(text)
                        val room = NetworkRoom(
                            sessionId = announcement.sessionId,
                            roomName = announcement.roomName,
                            hostAddress = packet.address.hostAddress ?: announcement.hostAddress,
                            port = announcement.port,
                            connectedPlayers = announcement.connectedPlayers,
                            maxPlayers = announcement.maxPlayers,
                        )
                        found[room.sessionId] = room
                        _networkState.value = _networkState.value.copy(rooms = found.values.toList(), statusText = "تم العثور على ${found.size} غرفة")
                    }
                }
            }.onFailure {
                _networkState.value = _networkState.value.copy(statusText = "تعذر البحث التلقائي. تأكد من اتصال Wi‑Fi/Hotspot")
            }
        }
    }

    fun broadcastSnapshot(snapshot: NetworkGameSnapshot) {
        if (_networkState.value.role != NetworkRole.HOST) return
        val message = NetworkMessage.Snapshot(sessionId, snapshot)
        clientConnections.values.forEach { connection -> connection.send(message) }
        _networkState.value = _networkState.value.copy(
            connectedPlayerIds = snapshot.connectedPlayerIds,
            status = NetworkStatus.CONNECTED,
            statusText = "تمت المزامنة v${snapshot.version}",
        )
    }

    fun sendPlayMove(playerId: Int, tile: DominoTile, side: BoardSide) {
        if (_networkState.value.role != NetworkRole.CLIENT) return
        sendToHost(NetworkMessage.PlayMove(sessionId, playerId, tile.id, tile.label(), side.name))
    }

    fun sendDrawOrPass(playerId: Int) {
        if (_networkState.value.role != NetworkRole.CLIENT) return
        sendToHost(NetworkMessage.DrawOrPass(sessionId, playerId))
    }

    fun sendResyncRequest(reason: String = "desync") {
        if (_networkState.value.role != NetworkRole.CLIENT) return
        sendToHost(NetworkMessage.ResyncRequest(sessionId, localPlayerId, reason))
    }

    fun stopNetworking(keepRooms: Boolean = false) {
        announceJob?.cancel()
        discoveryJob?.cancel()
        hostServer?.close()
        clientSocket?.close()
        clientConnections.values.forEach { it.close() }
        clientConnections.clear()
        if (!keepRooms) {
            _networkState.value = NetworkUiState(rooms = emptyList())
        }
    }

    private fun startHostServer() {
        scope.launch {
            runCatching {
                val server = ServerSocket(MessageProtocol.PORT)
                hostServer = server
                while (isActive) {
                    val socket = server.accept()
                    launch { handleClient(socket) }
                }
            }.onFailure {
                _networkState.value = _networkState.value.copy(status = NetworkStatus.DISCONNECTED, statusText = "تعذر فتح المنفذ المحلي")
            }
        }
    }

    private suspend fun handleClient(socket: Socket) {
        val connection = PeerConnection(socket)
        var assignedId: Int? = null
        runCatching {
            while (true) {
                val message = connection.read() ?: break
                when (message) {
                    is NetworkMessage.Hello -> {
                        val id = firstFreePlayerId()
                        if (id == null) {
                            connection.close()
                            return
                        }
                        assignedId = id
                        clientConnections[id] = connection
                        val connected = (listOf(0) + clientConnections.keys).sorted()
                        _networkState.value = _networkState.value.copy(connectedPlayerIds = connected, statusText = "متصلون: ${connected.size}/4")
                        _events.emit(NetworkEvent.ClientJoined(id))
                    }
                    is NetworkMessage.PlayMove -> _events.emit(NetworkEvent.PlayMoveRequest(message.playerId, message.tileId, BoardSide.valueOf(message.side)))
                    is NetworkMessage.DrawOrPass -> _events.emit(NetworkEvent.DrawOrPassRequest(message.playerId))
                    is NetworkMessage.ResyncRequest -> _events.emit(NetworkEvent.ResyncRequested(message.playerId, message.reason))
                    else -> Unit
                }
            }
        }.onFailure {
            assignedId?.let { _events.tryEmit(NetworkEvent.ClientDisconnected(it)) }
        }
        assignedId?.let { id ->
            clientConnections.remove(id)
            val connected = (listOf(0) + clientConnections.keys).sorted()
            _networkState.value = _networkState.value.copy(connectedPlayerIds = connected, status = NetworkStatus.DISCONNECTED, statusText = "انقطع لاعب $id مؤقتاً")
            _events.tryEmit(NetworkEvent.ClientDisconnected(id))
        }
    }

    fun welcomeClient(playerId: Int, snapshot: NetworkGameSnapshot) {
        clientConnections[playerId]?.send(NetworkMessage.Welcome(sessionId, playerId, snapshot))
        broadcastSnapshot(snapshot)
    }

    private suspend fun listenToHost(connection: PeerConnection) {
        runCatching {
            while (true) {
                when (val message = connection.read() ?: break) {
                    is NetworkMessage.Welcome -> {
                        localPlayerId = message.assignedPlayerId
                        _networkState.value = _networkState.value.copy(
                            status = NetworkStatus.CONNECTED,
                            localPlayerId = localPlayerId,
                            connectedPlayerIds = message.snapshot.connectedPlayerIds,
                            statusText = "متصل كلاعب ${localPlayerId + 1}",
                        )
                        _events.emit(NetworkEvent.SnapshotReceived(message.snapshot, true))
                    }
                    is NetworkMessage.Snapshot -> {
                        _networkState.value = _networkState.value.copy(status = NetworkStatus.CONNECTED, connectedPlayerIds = message.snapshot.connectedPlayerIds)
                        _events.emit(NetworkEvent.SnapshotReceived(message.snapshot, false))
                    }
                    else -> Unit
                }
            }
        }.onFailure {
            _networkState.value = _networkState.value.copy(status = NetworkStatus.DISCONNECTED, statusText = "انقطع الاتصال بالمضيف")
        }
    }

    private fun sendToHost(message: NetworkMessage) {
        scope.launch { runCatching { clientSocket?.let { PeerConnection(it).send(message) } } }
    }

    private fun startRoomAnnouncements(roomName: String) {
        announceJob?.cancel()
        announceJob = scope.launch {
            val group = InetAddress.getByName(MessageProtocol.MULTICAST_GROUP)
            MulticastSocket().use { socket ->
                while (isActive) {
                    val announcement = RoomAnnouncement(
                        sessionId = sessionId,
                        roomName = roomName,
                        hostAddress = localAddress(),
                        port = MessageProtocol.PORT,
                        connectedPlayers = _networkState.value.connectedPlayerIds.size,
                    )
                    val data = MessageProtocol.json.encodeToString(RoomAnnouncement.serializer(), announcement).toByteArray()
                    socket.send(DatagramPacket(data, data.size, group, MessageProtocol.DISCOVERY_PORT))
                    kotlinx.coroutines.delay(1_000L)
                }
            }
        }
    }

    private fun firstFreePlayerId(): Int? = (1..3).firstOrNull { it !in clientConnections.keys }

    private fun localAddress(): String = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }
            ?.hostAddress ?: "0.0.0.0"
    }.getOrDefault("0.0.0.0")
}

class PeerConnection(private val socket: Socket) {
    private val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
    private val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream()))

    @Synchronized
    fun send(message: NetworkMessage) {
        writer.write(MessageProtocol.encode(message))
        writer.newLine()
        writer.flush()
    }

    fun read(): NetworkMessage? = reader.readLine()?.let { MessageProtocol.decode(it) }

    fun close() { runCatching { socket.close() } }
}

data class NetworkUiState(
    val role: NetworkRole = NetworkRole.OFFLINE,
    val status: NetworkStatus = NetworkStatus.OFFLINE,
    val sessionId: String = "",
    val roomName: String = "",
    val localPlayerId: Int? = null,
    val connectedPlayerIds: List<Int> = emptyList(),
    val rooms: List<NetworkRoom> = emptyList(),
    val statusText: String = "Offline",
)

sealed class NetworkEvent {
    data class ClientJoined(val playerId: Int) : NetworkEvent()
    data class ClientDisconnected(val playerId: Int) : NetworkEvent()
    data class SnapshotReceived(val snapshot: NetworkGameSnapshot, val isWelcome: Boolean) : NetworkEvent()
    data class PlayMoveRequest(val playerId: Int, val tileId: Int, val side: BoardSide) : NetworkEvent()
    data class DrawOrPassRequest(val playerId: Int) : NetworkEvent()
    data class ResyncRequested(val playerId: Int, val reason: String) : NetworkEvent()
}
