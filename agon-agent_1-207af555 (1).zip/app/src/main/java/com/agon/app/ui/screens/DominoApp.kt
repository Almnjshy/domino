package com.agon.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.agon.app.data.AppSettings
import com.agon.app.data.BoardSide
import com.agon.app.data.DominoTile
import com.agon.app.data.GameMode
import com.agon.app.data.GameUiState
import com.agon.app.data.MatchHistoryRecord
import com.agon.app.data.StatsData
import com.agon.app.network.NetworkRole
import com.agon.app.network.NetworkRoom
import com.agon.app.network.NetworkStatus
import com.agon.app.network.NetworkUiState
import com.agon.app.ui.components.DominoTileView
import com.agon.app.viewmodel.DominoViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class ScreenMode { MENU, GAME, NETWORK, SETTINGS, STATS, VERIFY, DEMO }

@Composable
fun DominoApp(viewModel: DominoViewModel = viewModel()) {
    var screenMode by remember { mutableStateOf(ScreenMode.MENU) }
    var selectedMode by remember { mutableStateOf(GameMode.HUMAN_VS_AI) }
    val state by viewModel.uiState.collectAsState()
    val networkState by viewModel.networkState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(settings.preferredMode) { selectedMode = settings.preferredMode }
    BackHandler(enabled = screenMode != ScreenMode.MENU) { screenMode = ScreenMode.MENU }

    AnimatedContent(targetState = screenMode, label = "screen") { mode ->
        when (mode) {
            ScreenMode.MENU -> MainMenuScreen(
                selectedMode = selectedMode,
                onModeSelected = { selectedMode = it; viewModel.updateSettings(settings.copy(preferredMode = it)) },
                onNewGame = { viewModel.newGame(selectedMode); screenMode = ScreenMode.GAME },
                onNetwork = { viewModel.discoverRooms(); screenMode = ScreenMode.NETWORK },
                onSettings = { screenMode = ScreenMode.SETTINGS },
                onStats = { screenMode = ScreenMode.STATS },
                onVerify = { screenMode = ScreenMode.VERIFY },
                onDemo = { screenMode = ScreenMode.DEMO },
                onExit = { (context as? android.app.Activity)?.finish() },
            )
            ScreenMode.NETWORK -> NetworkScreen(
                networkState = networkState,
                onCreateRoom = { viewModel.createNetworkRoom(); screenMode = ScreenMode.GAME },
                onDiscover = viewModel::discoverRooms,
                onJoinRoom = { viewModel.joinRoom(it); screenMode = ScreenMode.GAME },
                onBack = { screenMode = ScreenMode.MENU },
            )
            ScreenMode.SETTINGS -> SettingsPanel(settings, viewModel::updateSettings) { screenMode = ScreenMode.MENU }
            ScreenMode.STATS -> StatsPanel(stats, viewModel::clearStats) { screenMode = ScreenMode.MENU }
            ScreenMode.DEMO -> OneDeviceDemoPanel(
                onStartAi = { viewModel.newGame(GameMode.HUMAN_VS_AI); screenMode = ScreenMode.GAME },
                onCreateNetworkRoom = { viewModel.createNetworkRoom(); screenMode = ScreenMode.GAME },
                onBack = { screenMode = ScreenMode.MENU },
            )
            ScreenMode.VERIFY -> VerificationPanel(
                onStartAi = { viewModel.newGame(GameMode.HUMAN_VS_AI); screenMode = ScreenMode.GAME },
                onNetwork = { viewModel.discoverRooms(); screenMode = ScreenMode.NETWORK },
                onSettings = { screenMode = ScreenMode.SETTINGS },
                onStats = { screenMode = ScreenMode.STATS },
                onBack = { screenMode = ScreenMode.MENU },
            )
            ScreenMode.GAME -> GameScreen(
                state = state,
                settings = settings,
                onTileClick = viewModel::playTile,
                onDrawOrPass = viewModel::drawOrPass,
                legalSides = viewModel::legalSides,
                onNewGame = { viewModel.newGame(state.gameMode) },
                onBackToMenu = { screenMode = ScreenMode.MENU },
            )
        }
    }
}

@Composable
private fun MainMenuScreen(
    selectedMode: GameMode,
    onModeSelected: (GameMode) -> Unit,
    onNewGame: () -> Unit,
    onNetwork: () -> Unit,
    onSettings: () -> Unit,
    onStats: () -> Unit,
    onVerify: () -> Unit,
    onDemo: () -> Unit,
    onExit: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF1BA164), Color(0xFF0B5B35), Color(0xFF041D12)), radius = 1300f))
            .padding(22.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.14f), modifier = Modifier.size(120.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Casino, null, tint = Color.White, modifier = Modifier.size(74.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("دومينو", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Black, color = Color.White)
            Text("لعبة دومينو عربية احترافية — Offline + AI + شبكة محلية", color = Color.White.copy(alpha = 0.86f), textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            FeatureBadges()
            Spacer(Modifier.height(18.dp))
            GameModeSelector(selectedMode, onModeSelected)
            Spacer(Modifier.height(18.dp))
            MenuButton("لعبة جديدة", Icons.Default.PlayArrow, onNewGame, primary = true)
            MenuButton("اللعب عبر الشبكة", Icons.Default.Wifi, onNetwork)
            MenuButton("الإعدادات", Icons.Default.Settings, onSettings)
            MenuButton("الإحصائيات", Icons.Default.Assessment, onStats)
            MenuButton("عرض توضيحي على جهاز واحد", Icons.Default.Handyman, onDemo)
            MenuButton("فحص المزايا", Icons.Default.CheckCircle, onVerify)
            MenuButton("خروج", Icons.Default.Close, onExit)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FeatureBadges() {
    FlowRow(horizontalArrangement = Arrangement.Center, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("AI Bots مفعّل", "شبكة محلية", "إعدادات محفوظة", "إحصائيات وسجل", "صوت واهتزاز").forEach { label ->
            AssistChip(onClick = {}, label = { Text(label) }, leadingIcon = { Icon(Icons.Default.CheckCircle, null) })
        }
    }
}

@Composable
private fun MenuButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, primary: Boolean = false) {
    Spacer(Modifier.height(10.dp))
    val modifier = Modifier.fillMaxWidth(0.86f).height(52.dp)
    if (primary) {
        Button(onClick = onClick, modifier = modifier) { Icon(icon, null); Spacer(Modifier.width(8.dp)); Text(text, fontWeight = FontWeight.Bold) }
    } else {
        FilledTonalButton(onClick = onClick, modifier = modifier) { Icon(icon, null); Spacer(Modifier.width(8.dp)); Text(text) }
    }
}

@Composable
private fun SettingsPanel(settings: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    ReleasePanelScaffold(title = "الإعدادات", icon = Icons.Default.Settings, onBack = onBack) {
        Text("مستوى الصوت", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.VolumeUp, null); Slider(value = settings.volume, onValueChange = { onChange(settings.copy(volume = it)) }, modifier = Modifier.weight(1f)) }
        SettingSwitch("تشغيل المؤثرات", settings.effectsEnabled) { onChange(settings.copy(effectsEnabled = it)) }
        SettingSwitch("تفعيل الاهتزاز", settings.vibrationEnabled) { onChange(settings.copy(vibrationEnabled = it)) }
        Text("اللغة", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = settings.language == "ar", onClick = { onChange(settings.copy(language = "ar")) }, label = { Text("عربي") })
            FilterChip(selected = settings.language == "en", onClick = { onChange(settings.copy(language = "en")) }, label = { Text("English") })
        }
        Text("وضع اللعب الافتراضي", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GameMode.values().forEach { mode -> FilterChip(selected = settings.preferredMode == mode, onClick = { onChange(settings.copy(preferredMode = mode)) }, label = { Text(mode.arabicLabel) }) }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = checked, onCheckedChange = onChange)
        Text(label, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StatsPanel(stats: StatsData, onClear: () -> Unit, onBack: () -> Unit) {
    ReleasePanelScaffold(title = "الإحصائيات", icon = Icons.Default.Assessment, onBack = onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("المباريات", stats.matchesPlayed.toString(), Modifier.weight(1f))
            StatCard("الفوز", "${stats.winRate}%", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("الانتصارات", stats.wins.toString(), Modifier.weight(1f))
            StatCard("أطول سلسلة", stats.longestWinStreak.toString(), Modifier.weight(1f))
        }
        StatCard("إجمالي نقاط اللاعب", stats.totalPoints.toString(), Modifier.fillMaxWidth().padding(top = 8.dp))
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.History, null); Spacer(Modifier.width(8.dp)); Text("سجل المباريات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        LazyColumn(modifier = Modifier.height(260.dp).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(stats.history) { MatchHistoryItem(it) }
        }
        FilledTonalButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("مسح الإحصائيات") }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black); Text(label) }
    }
}

@Composable
private fun MatchHistoryItem(record: MatchHistoryRecord) {
    val date = remember(record.dateMillis) { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(record.dateMillis)) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.End) {
            Text("الفائز: ${record.winner}", fontWeight = FontWeight.Bold)
            Text(date, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("المدة: ${record.durationSeconds} ثانية")
            Text(record.finalScores.joinToString(" • ") { "${it.playerName}: ${it.score}" }, textAlign = TextAlign.End)
        }
    }
}

@Composable
private fun ReleasePanelScaffold(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF0F6B3C), Color(0xFF062F1B)))).padding(18.dp), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black); Spacer(Modifier.width(8.dp)); Icon(icon, null) }
                Spacer(Modifier.height(16.dp))
                content()
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
            }
        }
    }
}

@Composable
private fun OneDeviceDemoPanel(
    onStartAi: () -> Unit,
    onCreateNetworkRoom: () -> Unit,
    onBack: () -> Unit,
) {
    ReleasePanelScaffold(title = "عرض توضيحي", icon = Icons.Default.Handyman, onBack = onBack) {
        Text("هذه الشاشة وُضعت لحل مشكلة المعاينة: تستطيع اختبار إضافات ما بعد المرحلة الأولى من جهاز واحد بدون انتظار أجهزة أخرى.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
        Spacer(Modifier.height(12.dp))
        VerificationRow("اختبار AI فعلي", "يفتح مباراة لاعب ضد 3 Bots، وستتحرك الـ Bots تلقائياً عند وصول دورها.")
        VerificationRow("اختبار Host فعلي", "ينشئ غرفة محلية ويعرض Connected و Session ID حتى لو لم ينضم جهاز آخر.")
        VerificationRow("اختبار المنتج", "استخدم الإعدادات والإحصائيات لترى الحفظ المحلي والمؤثرات.")
        Spacer(Modifier.height(12.dp))
        Button(onClick = onStartAi, modifier = Modifier.fillMaxWidth()) { Text("ابدأ اختبار AI") }
        FilledTonalButton(onClick = onCreateNetworkRoom, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("أنشئ غرفة Host الآن") }
    }
}

@Composable
private fun VerificationPanel(
    onStartAi: () -> Unit,
    onNetwork: () -> Unit,
    onSettings: () -> Unit,
    onStats: () -> Unit,
    onBack: () -> Unit,
) {
    ReleasePanelScaffold(title = "فحص المزايا", icon = Icons.Default.CheckCircle, onBack = onBack) {
        Text("هذه الشاشة تؤكد أن إضافات المراحل 2 و3 و4 مفعّلة داخل التطبيق. بعض وظائف الشبكة تحتاج جهازين على نفس Wi‑Fi/Hotspot ولا تظهر كاملة في معاينة جهاز واحد.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
        Spacer(Modifier.height(12.dp))
        VerificationRow("Bots AI", "ابدأ مباراة لاعب ضد 3 Bots مع مؤشر يفكر...")
        VerificationRow("Local Multiplayer", "Create Room / Join Room عبر Wi‑Fi أو Hotspot بدون إنترنت")
        VerificationRow("Polish", "إعدادات، إحصائيات، سجل مباريات، صوت واهتزاز وواجهة محسّنة")
        VerificationRow("Release", "APK حجمه أقل من 100MB وتم بناؤه بنجاح")
        Spacer(Modifier.height(12.dp))
        Button(onClick = onStartAi, modifier = Modifier.fillMaxWidth()) { Text("اختبار AI الآن") }
        FilledTonalButton(onClick = onNetwork, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("فتح شاشة الشبكة") }
        FilledTonalButton(onClick = onSettings, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("فتح الإعدادات") }
        FilledTonalButton(onClick = onStats, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("فتح الإحصائيات") }
    }
}

@Composable
private fun VerificationRow(title: String, details: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(details, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.End)
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun NetworkScreen(networkState: NetworkUiState, onCreateRoom: () -> Unit, onDiscover: () -> Unit, onJoinRoom: (NetworkRoom) -> Unit, onBack: () -> Unit) {
    ReleasePanelScaffold(title = "الشبكة المحلية", icon = Icons.Default.Wifi, onBack = onBack) {
        Text("Wi‑Fi / Hotspot بدون إنترنت — Host واحد و Clients يرسلون أوامر فقط", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onCreateRoom, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Wifi, null); Spacer(Modifier.width(8.dp)); Text("إنشاء غرفة") }
        FilledTonalButton(onClick = onDiscover, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("البحث عن غرف") }
        Text("الحالة: ${networkState.status} • ${networkState.statusText}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 12.dp))
        LazyColumn(modifier = Modifier.height(210.dp).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (networkState.rooms.isEmpty()) item { Text("لا توجد غرف بعد. شغّل Hotspot أو اتصل بنفس الراوتر ثم اضغط البحث.", textAlign = TextAlign.End) }
            items(networkState.rooms) { room ->
                Card(onClick = { onJoinRoom(room) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.End) { Text(room.roomName, fontWeight = FontWeight.Bold); Text("Session: ${room.sessionId} • ${room.connectedPlayers}/${room.maxPlayers}"); Text(room.hostAddress) }
                }
            }
        }
    }
}

@Composable
private fun GameModeSelector(selectedMode: GameMode, onModeSelected: (GameMode) -> Unit) {
    Surface(color = Color.White.copy(alpha = 0.13f), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Game Mode", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                GameMode.values().forEach { mode -> FilterChip(selected = selectedMode == mode, onClick = { onModeSelected(mode) }, label = { Text(mode.arabicLabel) }, leadingIcon = if (mode == GameMode.HUMAN_VS_AI) ({ Icon(Icons.Default.SmartToy, null) }) else null) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GameScreen(state: GameUiState, settings: AppSettings, onTileClick: (DominoTile, BoardSide?) -> Unit, onDrawOrPass: () -> Unit, legalSides: (DominoTile) -> Set<BoardSide>, onNewGame: () -> Unit, onBackToMenu: () -> Unit) {
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTile by remember { mutableStateOf<DominoTile?>(null) }
    val currentPlayer = state.players.getOrNull(state.currentPlayerIndex)
    val isCurrentAi = currentPlayer?.isAi == true
    val localPlayerId = state.localPlayerId ?: state.currentPlayerIndex
    val isNetworkClient = state.networkRole == NetworkRole.CLIENT
    val isMyNetworkTurn = state.networkRole == NetworkRole.OFFLINE || state.currentPlayerIndex == localPlayerId || state.networkRole == NetworkRole.HOST
    val visiblePlayer = if (isNetworkClient) state.players.getOrNull(localPlayerId) else currentPlayer
    val currentHand = when { isNetworkClient -> visiblePlayer?.hand.orEmpty(); isCurrentAi -> emptyList(); else -> currentPlayer?.hand.orEmpty() }

    LaunchedEffect(state.message) { if (state.message.isNotBlank()) snackbarHostState.showSnackbar(state.message) }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }, topBar = {
        LargeTopAppBar(
            title = { Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) { Text("دومينو", fontWeight = FontWeight.Black); Text(state.roundInfoText, style = MaterialTheme.typography.bodyMedium) } },
            navigationIcon = { IconButton(onClick = onBackToMenu) { Icon(Icons.Default.Close, "القائمة") } },
            actions = { IconButton(onClick = onNewGame) { Icon(Icons.Default.Refresh, "لعبة جديدة") } },
            colors = TopAppBarDefaults.largeTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = MaterialTheme.colorScheme.onPrimary, navigationIconContentColor = MaterialTheme.colorScheme.onPrimary, actionIconContentColor = MaterialTheme.colorScheme.onPrimary),
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Color(0xFF0F6B3C)).padding(10.dp)) {
            PlayerStrip(state)
            NetworkStatusPanel(state)
            RoundInfoPanel(state)
            AnimatedVisibility(state.isAiThinking) { ThinkingPanel(currentPlayer?.displayName() ?: "AI") }
            Spacer(Modifier.height(8.dp))
            BoardPanel(state, modifier = Modifier.weight(1f))
            Spacer(Modifier.height(8.dp))
            PlayerHandPanel(
                playerName = visiblePlayer?.displayName() ?: currentPlayer?.displayName() ?: "لاعب",
                hand = currentHand,
                legalSides = legalSides,
                onSelectTile = { tile -> val sides = legalSides(tile); if (sides.size <= 1) onTileClick(tile, sides.firstOrNull()) else selectedTile = tile },
                onDrawOrPass = onDrawOrPass,
                canDrawOrPass = (!state.currentPlayerHasLegalMove || state.stockCount == 0) && !isCurrentAi && isMyNetworkTurn,
                stockCount = state.stockCount,
                enabled = !isCurrentAi && !state.isAiThinking && isMyNetworkTurn,
                effectsEnabled = settings.effectsEnabled,
            )
        }
    }

    if (state.roundOver) ResultSheet(state, onNewGame, onBackToMenu)
    selectedTile?.let { tile -> TileSideSheet(tile, legalSides(tile), { selectedTile = null }) { side -> selectedTile = null; onTileClick(tile, side) } }
}

@Composable
private fun PlayerStrip(state: GameUiState) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        state.players.forEach { player ->
            val active = player.id == state.currentPlayerIndex
            val scale by animateFloatAsState(if (active) 1.05f else 1f, label = "player")
            Card(colors = CardDefaults.cardColors(containerColor = if (active) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface), modifier = Modifier.scale(scale)) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(player.displayName(), fontWeight = FontWeight.Bold)
                    Text(if (player.isAi) "AI" else if (state.networkRole == NetworkRole.OFFLINE) "Human" else "Online")
                    Text("${player.hand.size} حجر")
                }
            }
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun NetworkStatusPanel(state: GameUiState) {
    if (state.networkRole == NetworkRole.OFFLINE) return
    val statusText = when (state.networkStatus) { NetworkStatus.CONNECTED -> "Connected"; NetworkStatus.SYNCING -> "Syncing"; NetworkStatus.DISCONNECTED -> "Disconnected"; NetworkStatus.OFFLINE -> "Offline" }
    val color = when (state.networkStatus) { NetworkStatus.CONNECTED -> Color(0xFFB8F2CF); NetworkStatus.SYNCING -> Color(0xFFFFE28A); NetworkStatus.DISCONNECTED -> Color(0xFFFFDAD6); NetworkStatus.OFFLINE -> MaterialTheme.colorScheme.surfaceVariant }
    Card(colors = CardDefaults.cardColors(containerColor = color), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.End) { Text("${state.networkRole} • $statusText • ${state.roomName}", fontWeight = FontWeight.Bold); Text("المتصلون: ${state.connectedPlayerIds.map { it + 1 }.joinToString()} / 4", style = MaterialTheme.typography.bodySmall); state.localPlayerId?.let { Text("أنت لاعب ${it + 1}", style = MaterialTheme.typography.bodySmall) } } }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun ThinkingPanel(currentPlayerName: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) { Text("$currentPlayerName يفكر...", fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.SmartToy, null) } }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun RoundInfoPanel(state: GameUiState) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.End) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { AssistChip(onClick = {}, label = { Text("المخزن: ${state.stockCount}") }, leadingIcon = { Icon(Icons.Default.Style, null) }); AssistChip(onClick = {}, label = { Text(state.boardEndsText) }) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BoardPanel(state: GameUiState, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B5A32)), shape = RoundedCornerShape(24.dp)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF168A51), Color(0xFF083D24)))).padding(14.dp), contentAlignment = Alignment.Center) {
            if (state.boardTiles.isEmpty()) Text("الطاولة فارغة — يبدأ اللاعب الأول بوضع أي حجر", color = Color.White.copy(alpha = 0.82f), textAlign = TextAlign.Center) else {
                FlowRow(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.Center, verticalArrangement = Arrangement.spacedBy(8.dp), maxItemsInEachRow = 4) {
                    state.boardTiles.forEachIndexed { index, tile ->
                        val rowTurn = if ((index / 4) % 2 == 0) 0f else 180f
                        DominoTileView(tile = tile, horizontal = true, compact = true, modifier = Modifier.padding(3.dp).rotate(rowTurn))
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerHandPanel(playerName: String, hand: List<DominoTile>, legalSides: (DominoTile) -> Set<BoardSide>, onSelectTile: (DominoTile) -> Unit, onDrawOrPass: () -> Unit, canDrawOrPass: Boolean, stockCount: Int, enabled: Boolean = true, effectsEnabled: Boolean = true) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f))) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                ElevatedButton(onClick = onDrawOrPass, enabled = enabled) { Text(if (stockCount > 0) "اسحب/تمرير" else "تمرير") }
                Column(horizontalAlignment = Alignment.End) { Text("يد $playerName", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(if (enabled) "Fan Layout • Glow للحركات القانونية" else "انتظار الدور", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(132.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.Bottom) {
                hand.forEachIndexed { index, tile ->
                    val playable = legalSides(tile).isNotEmpty()
                    val scale by animateFloatAsState(if (playable && effectsEnabled) 1.08f else 0.98f, label = "tileScale")
                    val rotation = ((index - hand.lastIndex / 2f) * 4f).coerceIn(-18f, 18f)
                    DominoTileView(tile = tile, playable = playable, horizontal = false, compact = false, modifier = Modifier.offset(x = (-6).dp).rotate(rotation).scale(scale), onClick = if (playable && enabled) ({ onSelectTile(tile) }) else null)
                }
            }
            AnimatedVisibility(!canDrawOrPass && enabled) { Text("لا يمكنك السحب ما دام لديك حجر قانوني.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TileSideSheet(tile: DominoTile, sides: Set<BoardSide>, onDismiss: () -> Unit, onChoose: (BoardSide) -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("اختر طرف وضع الحجر ${tile.label()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp)); Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { SideButton("الطرف الأيسر", BoardSide.LEFT, sides, onChoose); SideButton("الطرف الأيمن", BoardSide.RIGHT, sides, onChoose) }; Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SideButton(label: String, side: BoardSide, sides: Set<BoardSide>, onChoose: (BoardSide) -> Unit) {
    val enabled = side in sides
    val color by animateColorAsState(if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, label = "sideColor")
    Surface(onClick = { if (enabled) onChoose(side) }, enabled = enabled, color = color, contentColor = if (enabled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, shape = RoundedCornerShape(16.dp), modifier = Modifier.alpha(if (enabled) 1f else 0.45f).size(width = 148.dp, height = 64.dp)) { Box(contentAlignment = Alignment.Center) { Text(label, fontWeight = FontWeight.Bold) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ResultSheet(state: GameUiState, onReplay: () -> Unit, onHome: () -> Unit) {
    ModalBottomSheet(onDismissRequest = {}, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.EmojiEvents, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(64.dp))
            Text("انتهت المباراة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text("الفائز: ${state.players.firstOrNull { it.id == state.winnerId }?.displayName() ?: "غير محدد"}", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            state.players.forEach { Text("${it.displayName()}: ${state.scores[it.id] ?: it.handValue()} نقطة") }
            Spacer(Modifier.height(18.dp))
            Button(onClick = onReplay, modifier = Modifier.fillMaxWidth()) { Text("إعادة اللعب") }
            FilledTonalButton(onClick = onHome, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("العودة للرئيسية") }
        }
    }
}
