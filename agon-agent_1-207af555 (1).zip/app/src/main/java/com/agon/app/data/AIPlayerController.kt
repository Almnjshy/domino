package com.agon.app.data

/**
 * وحدة ذكاء اصطناعي مستقلة لا تغيّر القواعد ولا تلمس الأيدي مباشرة.
 * ترى فقط حالة الطاولة ويد اللاعب الحالي، ثم تطلب التنفيذ من GameManager.
 */
class AIPlayerController {
    fun playTurn(gameManager: GameManager, playerId: Int): GameUiState {
        val state = gameManager.state()
        val player = state.players.getOrNull(playerId) ?: return state
        val move = chooseBestMove(player, state)
        return if (move != null) {
            gameManager.requestPlay(move.tile, playerId, move.side)
        } else {
            drawUntilMoveOrPass(gameManager, playerId)
        }
    }

    private fun drawUntilMoveOrPass(gameManager: GameManager, playerId: Int): GameUiState {
        while (true) {
            val currentState = gameManager.state()
            if (currentState.roundOver) return currentState
            val player = currentState.players.getOrNull(playerId) ?: return currentState
            chooseBestMove(player, currentState)?.let { move ->
                return gameManager.requestPlay(move.tile, playerId, move.side)
            }
            val afterDraw = gameManager.drawOneForCurrentPlayerOrPass(playerId)
            if (afterDraw.roundOver || afterDraw.currentPlayerIndex != playerId) return afterDraw
        }
    }

    private fun chooseBestMove(player: Player, state: GameUiState): AIMove? {
        val legalMoves = player.hand.flatMap { tile ->
            legalSides(tile, state).map { side -> AIMove(tile, side, scoreMove(tile, side, state)) }
        }
        return legalMoves.maxWithOrNull(
            compareBy<AIMove> { it.score }
                .thenBy { it.tile.sum }
                .thenBy { it.tile.highestSide }
        )
    }

    private fun legalSides(tile: DominoTile, state: GameUiState): Set<BoardSide> {
        if (state.boardTiles.isEmpty()) return setOf(BoardSide.RIGHT)
        val sides = mutableSetOf<BoardSide>()
        val left = state.leftEnd
        val right = state.rightEnd
        if (left != null && (tile.left == left || tile.right == left)) sides.add(BoardSide.LEFT)
        if (right != null && (tile.left == right || tile.right == right)) sides.add(BoardSide.RIGHT)
        return sides
    }

    private fun scoreMove(tile: DominoTile, side: BoardSide, state: GameUiState): Int {
        if (state.boardTiles.isEmpty()) return tile.sum * 10 + if (tile.isDouble) 18 else 0
        val left = state.leftEnd
        val right = state.rightEnd
        val matchesLeft = left != null && (tile.left == left || tile.right == left)
        val matchesRight = right != null && (tile.left == right || tile.right == right)
        val doubleMatchBonus = if (matchesLeft && matchesRight) 1000 else 0
        val highValueBonus = tile.sum * 25
        val riskReduction = if (tile.sum >= 9) 160 else if (tile.sum >= 7) 70 else 0
        val sidePreference = if (side == BoardSide.RIGHT) 4 else 0
        return doubleMatchBonus + highValueBonus + riskReduction + sidePreference
    }
}

data class AIMove(
    val tile: DominoTile,
    val side: BoardSide,
    val score: Int,
)
