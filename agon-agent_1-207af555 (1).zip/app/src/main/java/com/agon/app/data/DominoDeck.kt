package com.agon.app.data

/** مسؤول عن إنشاء وخلط وسحب مجموعة Double-Six القياسية. */
class DominoDeck {
    private val stock = ArrayDeque<DominoTile>()

    fun createShuffledDeck(): List<DominoTile> {
        var id = 0
        val tiles = buildList {
            for (left in 0..6) {
                for (right in left..6) {
                    add(DominoTile(id = id++, left = left, right = right))
                }
            }
        }.shuffled()
        stock.clear()
        stock.addAll(tiles)
        return tiles
    }

    fun setStock(tiles: List<DominoTile>) {
        stock.clear()
        stock.addAll(tiles)
    }

    fun draw(): DominoTile? = stock.removeFirstOrNull()

    fun drawMany(count: Int): List<DominoTile> = buildList {
        repeat(count) {
            draw()?.let { add(it) }
        }
    }

    fun remainingTiles(): List<DominoTile> = stock.toList()

    fun remainingCount(): Int = stock.size

    fun isEmpty(): Boolean = stock.isEmpty()
}
