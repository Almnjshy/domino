package com.agon.app.data

class StatsManager(private val saveManager: SaveManager) {
    fun load(): StatsData = saveManager.loadStats()

    fun recordMatch(state: GameUiState, durationSeconds: Long): StatsData {
        val previous = saveManager.loadStats()
        val winner = state.players.firstOrNull { it.id == state.winnerId }
        val humanWon = winner?.id == 0
        val points = state.scores[0] ?: state.players.firstOrNull { it.id == 0 }?.handValue() ?: 0
        val currentStreak = if (humanWon) previous.currentWinStreak + 1 else 0
        val record = MatchHistoryRecord(
            dateMillis = System.currentTimeMillis(),
            players = state.players.map { it.displayName() },
            winner = winner?.displayName() ?: "غير محدد",
            finalScores = state.players.map { PlayerScoreRecord(it.displayName(), state.scores[it.id] ?: it.handValue()) },
            durationSeconds = durationSeconds,
        )
        val updated = previous.copy(
            matchesPlayed = previous.matchesPlayed + 1,
            wins = previous.wins + if (humanWon) 1 else 0,
            currentWinStreak = currentStreak,
            longestWinStreak = maxOf(previous.longestWinStreak, currentStreak),
            totalPoints = previous.totalPoints + points,
            history = (listOf(record) + previous.history).take(30),
        )
        saveManager.saveStats(updated)
        return updated
    }

    fun clear(): StatsData {
        val empty = StatsData()
        saveManager.saveStats(empty)
        return empty
    }
}
