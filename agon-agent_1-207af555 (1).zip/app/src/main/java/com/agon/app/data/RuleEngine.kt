package com.agon.app.data

/** يطبق قواعد قانونية الحركة دون أي منطق واجهة. */
class RuleEngine {
    fun legalSides(tile: DominoTile, board: BoardManager): Set<BoardSide> {
        if (board.isEmpty) return setOf(BoardSide.RIGHT)
        val sides = mutableSetOf<BoardSide>()
        val leftEnd = board.leftEnd
        val rightEnd = board.rightEnd
        if (leftEnd != null && (tile.left == leftEnd || tile.right == leftEnd)) sides.add(BoardSide.LEFT)
        if (rightEnd != null && (tile.left == rightEnd || tile.right == rightEnd)) sides.add(BoardSide.RIGHT)
        return sides
    }

    fun canPlay(tile: DominoTile, board: BoardManager): Boolean = legalSides(tile, board).isNotEmpty()

    fun hasAnyLegalMove(player: Player, board: BoardManager): Boolean = player.hand.any { canPlay(it, board) }
}

enum class BoardSide { LEFT, RIGHT }
