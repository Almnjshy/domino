package com.agon.app.data

/** يدير سلسلة الطاولة واتجاه الأحجار الموضوعة. */
class BoardManager {
    private val playedTiles = mutableListOf<DominoTile>()

    val tiles: List<DominoTile> get() = playedTiles.toList()
    val leftEnd: Int? get() = playedTiles.firstOrNull()?.left
    val rightEnd: Int? get() = playedTiles.lastOrNull()?.right
    val isEmpty: Boolean get() = playedTiles.isEmpty()

    fun clear() {
        playedTiles.clear()
    }

    fun restore(tiles: List<DominoTile>) {
        playedTiles.clear()
        playedTiles.addAll(tiles)
    }

    fun placeFirst(tile: DominoTile): DominoTile {
        val oriented = tile.played()
        playedTiles.add(oriented)
        return oriented
    }

    fun placeLeft(tile: DominoTile): DominoTile? {
        val required = leftEnd ?: return placeFirst(tile)
        val oriented = when {
            tile.right == required -> tile
            tile.left == required -> tile.rotated()
            else -> return null
        }.played()
        playedTiles.add(0, oriented)
        return oriented
    }

    fun placeRight(tile: DominoTile): DominoTile? {
        val required = rightEnd ?: return placeFirst(tile)
        val oriented = when {
            tile.left == required -> tile
            tile.right == required -> tile.rotated()
            else -> return null
        }.played()
        playedTiles.add(oriented)
        return oriented
    }
}
