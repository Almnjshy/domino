package com.agon.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.AIPlayerController
import com.agon.app.data.AppSettings
import com.agon.app.data.AudioManager
import com.agon.app.data.BoardSide
import com.agon.app.data.DominoTile
import com.agon.app.data.EffectsManager
import com.agon.app.data.GameManager
import com.agon.app.data.GameMode
import com.agon.app.data.GameUiState
import com.agon.app.data.SaveManager
import com.agon.app.data.StatsData
import com.agon.app.data.StatsManager
import com.agon.app.network.GameSyncManager
import com.agon.app.network.NetworkEvent
import com.agon.app.network.NetworkManager
import com.agon.app.network.NetworkRole
import com.agon.app.network.NetworkRoom
import com.agon.app.network.NetworkStatus
import com.agon.app.network.NetworkUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class DominoViewModel(application: Application) : AndroidViewModel(application) {
    private val gameManager = GameManager()
    private val syncManager = GameSyncManager(gameManager)
    private val networkManager = NetworkManager()
    private val aiController = AIPlayerController()
    private val saveManager = SaveManager(application)
    private val statsManager = StatsManager(saveManager)
    private val audioManager = AudioManager()
    private val effectsManager = EffectsManager(application)
    private var matchStartedAt: Long = System.currentTimeMillis()
    private var lastRoundOverRecorded = false

    private val _settings = MutableStateFlow(saveManager.loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()
    private val _stats = MutableStateFlow(statsManager.load())
    val stats: StateFlow<StatsData> = _stats.asStateFlow()
    private val _uiState = MutableStateFlow(mergeNetwork(gameManager.state(), networkManager.networkState.value))
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()
    val networkState: StateFlow<NetworkUiState> = networkManager.networkState

    init {
        viewModelScope.launch {
            networkManager.networkState.collect { network ->
                _uiState.value = mergeNetwork(_uiState.value, network)
            }
        }
        viewModelScope.launch {
            networkManager.events.collect { event -> handleNetworkEvent(event) }
        }
    }

    fun newGame(mode: GameMode = _settings.value.preferredMode) {
        matchStartedAt = System.currentTimeMillis()
        lastRoundOverRecorded = false
        audioManager.playTurn(_settings.value)
        _uiState.value = mergeNetwork(gameManager.newGame(mode), networkManager.networkState.value)
        maybeRunAiTurn()
    }

    fun createNetworkRoom() {
        networkManager.createRoom("غرفة الدومينو")
        matchStartedAt = System.currentTimeMillis()
        lastRoundOverRecorded = false
        val state = gameManager.newGame(GameMode.FOUR_HUMANS)
        _uiState.value = mergeNetwork(state, networkManager.networkState.value).copy(message = "تم إنشاء غرفة محلية. انتظر انضمام اللاعبين.")
        broadcastHostSnapshot()
    }

    fun discoverRooms() = networkManager.startDiscovery()

    fun joinRoom(room: NetworkRoom) = networkManager.joinRoom(room, "لاعب")

    fun stopNetworking() {
        networkManager.stopNetworking()
        _uiState.value = mergeNetwork(gameManager.state(), networkManager.networkState.value)
    }

    fun updateSettings(settings: AppSettings) {
        _settings.value = settings
        saveManager.saveSettings(settings)
    }

    fun clearStats() {
        _stats.value = statsManager.clear()
    }

    fun playTile(tile: DominoTile, preferredSide: BoardSide? = null) {
        val currentState = _uiState.value
        val localId = currentState.localPlayerId ?: currentState.currentPlayerIndex
        if (currentState.networkRole == NetworkRole.CLIENT) {
            val side = chooseSide(tile, preferredSide)
            if (side != null && currentState.currentPlayerIndex == localId) {
                networkManager.sendPlayMove(localId, tile, side)
                audioManager.playPlace(_settings.value)
                effectsManager.lightImpact(_settings.value)
                _uiState.value = currentState.copy(networkStatus = NetworkStatus.SYNCING, message = "تم إرسال الحركة للمضيف للتحقق")
            } else {
                audioManager.playFail(_settings.value)
            }
            return
        }
        val currentPlayer = currentState.players.getOrNull(currentState.currentPlayerIndex)
        if (currentPlayer?.isAi == true) {
            _uiState.value = mergeNetwork(gameManager.state("انتظر: ${currentPlayer.displayName()} يفكر..."), networkManager.networkState.value)
            return
        }
        val playerId = currentState.currentPlayerIndex
        val side = chooseSide(tile, preferredSide)
        _uiState.value = if (side == null) {
            audioManager.playFail(_settings.value)
            mergeNetwork(gameManager.state("هذا الحجر غير قابل للعب الآن"), networkManager.networkState.value)
        } else {
            audioManager.playPlace(_settings.value)
            effectsManager.lightImpact(_settings.value)
            mergeNetwork(gameManager.requestPlay(tile, playerId, side), networkManager.networkState.value)
        }
        afterLocalStateChange(currentState.networkRole)
    }

    fun drawOrPass() {
        val currentState = _uiState.value
        val localId = currentState.localPlayerId ?: currentState.currentPlayerIndex
        if (currentState.networkRole == NetworkRole.CLIENT) {
            if (currentState.currentPlayerIndex == localId) {
                networkManager.sendDrawOrPass(localId)
                audioManager.playDraw(_settings.value)
                _uiState.value = currentState.copy(networkStatus = NetworkStatus.SYNCING, message = "تم إرسال طلب السحب/التمرير للمضيف")
            } else {
                audioManager.playFail(_settings.value)
            }
            return
        }
        val currentPlayer = currentState.players.getOrNull(currentState.currentPlayerIndex)
        if (currentPlayer?.isAi == true) {
            _uiState.value = mergeNetwork(gameManager.state("انتظر: ${currentPlayer.displayName()} يفكر..."), networkManager.networkState.value)
            return
        }
        audioManager.playDraw(_settings.value)
        _uiState.value = mergeNetwork(gameManager.drawUntilPlayableOrPass(currentState.currentPlayerIndex), networkManager.networkState.value)
        afterLocalStateChange(currentState.networkRole)
    }

    fun legalSides(tile: DominoTile): Set<BoardSide> = gameManager.legalSidesFor(tile)

    private fun afterLocalStateChange(role: NetworkRole) {
        recordRoundIfNeeded()
        if (role == NetworkRole.HOST) broadcastHostSnapshot()
        maybeRunAiTurn()
    }

    private fun chooseSide(tile: DominoTile, preferredSide: BoardSide?): BoardSide? {
        val legalSides = gameManager.legalSidesFor(tile)
        return preferredSide?.takeIf { it in legalSides }
            ?: when {
                BoardSide.RIGHT in legalSides -> BoardSide.RIGHT
                BoardSide.LEFT in legalSides -> BoardSide.LEFT
                else -> null
            }
    }

    private suspend fun handleNetworkEvent(event: NetworkEvent) {
        when (event) {
            is NetworkEvent.ClientJoined -> {
                val snapshot = syncManager.createSnapshot(connectedIds())
                networkManager.welcomeClient(event.playerId, snapshot)
                _uiState.value = mergeNetwork(gameManager.state("انضم لاعب ${event.playerId + 1}"), networkManager.networkState.value)
            }
            is NetworkEvent.ClientDisconnected -> {
                _uiState.value = mergeNetwork(gameManager.state("انقطع لاعب ${event.playerId + 1} مؤقتاً ويمكنه العودة بنفس الغرفة"), networkManager.networkState.value)
                broadcastHostSnapshot()
            }
            is NetworkEvent.PlayMoveRequest -> {
                if (networkManager.networkState.value.role == NetworkRole.HOST) {
                    val tile = gameManager.state().players.getOrNull(event.playerId)?.hand?.firstOrNull { it.id == event.tileId }
                    if (tile != null) {
                        gameManager.requestPlay(tile, event.playerId, event.side)
                        audioManager.playPlace(_settings.value)
                    } else {
                        audioManager.playFail(_settings.value)
                    }
                    _uiState.value = mergeNetwork(gameManager.state(), networkManager.networkState.value)
                    recordRoundIfNeeded()
                    broadcastHostSnapshot()
                }
            }
            is NetworkEvent.DrawOrPassRequest -> {
                if (networkManager.networkState.value.role == NetworkRole.HOST) {
                    gameManager.drawUntilPlayableOrPass(event.playerId)
                    audioManager.playDraw(_settings.value)
                    _uiState.value = mergeNetwork(gameManager.state(), networkManager.networkState.value)
                    recordRoundIfNeeded()
                    broadcastHostSnapshot()
                }
            }
            is NetworkEvent.ResyncRequested -> broadcastHostSnapshot()
            is NetworkEvent.SnapshotReceived -> {
                if (syncManager.needsResync(event.snapshot)) {
                    networkManager.sendResyncRequest("checksum mismatch")
                }
                val restored = syncManager.applySnapshot(event.snapshot)
                _uiState.value = mergeNetwork(restored, networkManager.networkState.value).copy(networkStatus = NetworkStatus.CONNECTED)
                recordRoundIfNeeded()
            }
        }
    }

    private fun maybeRunAiTurn() {
        val state = _uiState.value
        if (state.networkRole != NetworkRole.OFFLINE) return
        val currentPlayer = state.players.getOrNull(state.currentPlayerIndex) ?: return
        if (state.roundOver || !currentPlayer.isAi || state.isAiThinking) return
        viewModelScope.launch {
            _uiState.value = mergeNetwork(gameManager.state("${currentPlayer.displayName()} يفكر..."), networkManager.networkState.value).copy(isAiThinking = true)
            delay(Random.nextLong(1_000L, 2_001L))
            audioManager.playPlace(_settings.value)
            _uiState.value = mergeNetwork(aiController.playTurn(gameManager, currentPlayer.id), networkManager.networkState.value).copy(isAiThinking = false)
            recordRoundIfNeeded()
            maybeRunAiTurn()
        }
    }

    private fun recordRoundIfNeeded() {
        val state = _uiState.value
        if (state.roundOver && !lastRoundOverRecorded && state.players.isNotEmpty()) {
            lastRoundOverRecorded = true
            val duration = ((System.currentTimeMillis() - matchStartedAt) / 1000L).coerceAtLeast(1L)
            _stats.value = statsManager.recordMatch(state, duration)
            audioManager.playWin(_settings.value)
            effectsManager.lightImpact(_settings.value)
        }
    }

    private fun broadcastHostSnapshot() {
        if (networkManager.networkState.value.role == NetworkRole.HOST) {
            networkManager.broadcastSnapshot(syncManager.createSnapshot(connectedIds()))
            _uiState.value = mergeNetwork(gameManager.state(), networkManager.networkState.value)
        }
    }

    private fun connectedIds(): List<Int> = networkManager.networkState.value.connectedPlayerIds.ifEmpty { listOf(0) }

    private fun mergeNetwork(state: GameUiState, network: NetworkUiState): GameUiState = state.copy(
        networkRole = network.role,
        networkStatus = network.status,
        localPlayerId = network.localPlayerId,
        roomName = network.roomName.ifBlank { state.roomName },
        connectedPlayerIds = network.connectedPlayerIds,
    )
}
