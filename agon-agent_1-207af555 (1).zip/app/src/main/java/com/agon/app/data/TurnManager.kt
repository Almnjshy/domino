package com.agon.app.data

/** يدير ترتيب اللاعبين ومنع الحركة خارج الدور. */
class TurnManager(private val playerCount: Int = 4) {
    var currentPlayerIndex: Int = 0
        private set

    fun setFirstPlayer(index: Int) {
        currentPlayerIndex = index.coerceIn(0, playerCount - 1)
    }

    fun isCurrentPlayer(playerId: Int): Boolean = currentPlayerIndex == playerId

    fun advance(): Int {
        currentPlayerIndex = (currentPlayerIndex + 1) % playerCount
        return currentPlayerIndex
    }
}
