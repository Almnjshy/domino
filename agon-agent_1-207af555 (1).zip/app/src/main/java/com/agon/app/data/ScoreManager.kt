package com.agon.app.data

/** يحسب نقاط نهاية الجولة ويحدد الفائز بأقل مجموع متبقٍ. */
class ScoreManager {
    fun scores(players: List<Player>): Map<Int, Int> = players.associate { it.id to it.handValue() }

    fun winner(players: List<Player>): Player? = players.minWithOrNull(compareBy<Player> { it.handValue() }.thenBy { it.id })
}
