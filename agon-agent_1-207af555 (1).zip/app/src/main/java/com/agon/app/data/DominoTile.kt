package com.agon.app.data

import kotlin.math.max

/** حجر دومينو قياسي قابل للتدوير داخلياً. */
data class DominoTile(
    val id: Int,
    val left: Int,
    val right: Int,
    val isRotated: Boolean = false,
    val isPlayed: Boolean = false,
) {
    val isDouble: Boolean get() = left == right
    val sum: Int get() = left + right
    val highestSide: Int get() = max(left, right)

    fun rotated(): DominoTile = copy(left = right, right = left, isRotated = !isRotated)

    fun played(): DominoTile = copy(isPlayed = true)

    fun label(): String = "$left|$right"
}
