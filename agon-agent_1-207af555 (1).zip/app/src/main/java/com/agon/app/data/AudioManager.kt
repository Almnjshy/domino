package com.agon.app.data

import android.media.AudioManager as AndroidAudioManager
import android.media.ToneGenerator

class AudioManager {
    private val tone = ToneGenerator(AndroidAudioManager.STREAM_MUSIC, 80)

    fun playPlace(settings: AppSettings) = play(settings, ToneGenerator.TONE_PROP_ACK, 90)
    fun playDraw(settings: AppSettings) = play(settings, ToneGenerator.TONE_PROP_BEEP, 80)
    fun playTurn(settings: AppSettings) = play(settings, ToneGenerator.TONE_PROP_PROMPT, 70)
    fun playWin(settings: AppSettings) = play(settings, ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 220)
    fun playFail(settings: AppSettings) = play(settings, ToneGenerator.TONE_PROP_NACK, 130)

    private fun play(settings: AppSettings, toneType: Int, durationMs: Int) {
        if (!settings.effectsEnabled || settings.volume <= 0.01f) return
        runCatching { tone.startTone(toneType, durationMs) }
    }
}
