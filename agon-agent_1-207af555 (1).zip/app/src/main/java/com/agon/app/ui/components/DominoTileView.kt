package com.agon.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.agon.app.data.DominoTile

@Composable
fun DominoTileView(
    tile: DominoTile,
    modifier: Modifier = Modifier,
    playable: Boolean = true,
    horizontal: Boolean = false,
    compact: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val width = if (horizontal) if (compact) 76.dp else 96.dp else if (compact) 40.dp else 52.dp
    val height = if (horizontal) if (compact) 40.dp else 52.dp else if (compact) 76.dp else 96.dp
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .shadow(if (playable) 7.dp else 2.dp, shape)
            .alpha(if (playable) 1f else 0.42f)
            .size(width = width, height = height)
            .background(Color(0xFFFFFDF4), shape)
            .border(
                width = if (playable) 2.dp else 1.dp,
                color = if (playable) MaterialTheme.colorScheme.secondary else Color(0xFF8C8C8C),
                shape = shape,
            )
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(4.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (horizontal) {
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                PipHalf(tile.left, halfSize = height - 10.dp)
                Spacer(modifier = Modifier.width(4.dp))
                DividerLine(vertical = true)
                Spacer(modifier = Modifier.width(4.dp))
                PipHalf(tile.right, halfSize = height - 10.dp)
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                PipHalf(tile.left, halfSize = width - 10.dp)
                Spacer(modifier = Modifier.height(4.dp))
                DividerLine(vertical = false)
                Spacer(modifier = Modifier.height(4.dp))
                PipHalf(tile.right, halfSize = width - 10.dp)
            }
        }
    }
}

@Composable
private fun DividerLine(vertical: Boolean) {
    Canvas(modifier = if (vertical) Modifier.size(width = 1.dp, height = 31.dp) else Modifier.size(width = 31.dp, height = 1.dp)) {
        drawLine(
            color = Color(0xFF1C1C1C),
            start = Offset.Zero,
            end = if (vertical) Offset(0f, size.height) else Offset(size.width, 0f),
            strokeWidth = 2f,
            cap = StrokeCap.Round,
        )
    }
}

@Composable
private fun PipHalf(value: Int, halfSize: Dp) {
    Canvas(modifier = Modifier.size(halfSize)) {
        drawPips(value)
    }
}

private fun DrawScope.drawPips(value: Int) {
    val radius = size.minDimension * 0.075f
    val left = size.width * 0.25f
    val centerX = size.width * 0.5f
    val right = size.width * 0.75f
    val top = size.height * 0.25f
    val centerY = size.height * 0.5f
    val bottom = size.height * 0.75f
    val points = when (value) {
        1 -> listOf(Offset(centerX, centerY))
        2 -> listOf(Offset(left, top), Offset(right, bottom))
        3 -> listOf(Offset(left, top), Offset(centerX, centerY), Offset(right, bottom))
        4 -> listOf(Offset(left, top), Offset(right, top), Offset(left, bottom), Offset(right, bottom))
        5 -> listOf(Offset(left, top), Offset(right, top), Offset(centerX, centerY), Offset(left, bottom), Offset(right, bottom))
        6 -> listOf(Offset(left, top), Offset(right, top), Offset(left, centerY), Offset(right, centerY), Offset(left, bottom), Offset(right, bottom))
        else -> emptyList()
    }
    points.forEach { drawCircle(Color.Black, radius, it) }
}
