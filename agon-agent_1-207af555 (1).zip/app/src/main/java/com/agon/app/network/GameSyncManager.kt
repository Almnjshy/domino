package com.agon.app.network

import com.agon.app.data.GameManager
import com.agon.app.data.GameUiState

/** يبني ويراقب Snapshot كامل لمنع اختلاف الحالة بين الأجهزة. */
class GameSyncManager(private val gameManager: GameManager) {
    private var version: Long = 0L
    private var lastChecksum: Int = 0

    fun createSnapshot(connectedIds: List<Int>): NetworkGameSnapshot {
        version += 1
        val snapshot = gameManager.state().toSnapshot(
            stockTiles = gameManager.stockTiles(),
            version = version,
            connectedIds = connectedIds.sorted(),
        )
        lastChecksum = snapshot.checksum()
        return snapshot
    }

    fun applySnapshot(snapshot: NetworkGameSnapshot): GameUiState {
        version = snapshot.version
        lastChecksum = snapshot.checksum()
        return gameManager.restoreFromSnapshot(snapshot)
    }

    fun needsResync(snapshot: NetworkGameSnapshot): Boolean {
        val incomingChecksum = snapshot.checksum()
        return snapshot.version < version || (snapshot.version == version && lastChecksum != 0 && incomingChecksum != lastChecksum)
    }
}
